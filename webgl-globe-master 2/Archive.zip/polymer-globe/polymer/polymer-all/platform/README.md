Platform
========

Integration tests and builds for Polymer platform dependencies

mocha.setup({
  ui: 'tdd',
  slow: 1000,
  timeout: 8000,
  htmlbase: '/base/platform/test/'
});

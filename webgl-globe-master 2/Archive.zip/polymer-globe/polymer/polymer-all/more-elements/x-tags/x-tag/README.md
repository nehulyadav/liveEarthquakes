# Demo of a few X-Tags

This demo shows off spinner, toggle and switch X-Tag elements.
